<?php
/**
 * Template: home (จาก dth-v2.html) — คงหน้าตาและสคริปต์เดิม
 */
get_header();
?>
<a href="#main" class="skip">ข้ามไปยังเนื้อหาหลัก</a>

<!-- ===== Top utility bar ===== -->
<div class="topbar">
  <div class="wrap">
    <div class="left">
      <span>ปากเสียงเพื่อสิทธิและคุณภาพชีวิตที่เท่าเทียมของคนพิการทุกคน</span>
    </div>
    <div class="right">
      <span class="lang"><b>TH</b><span>|</span><a href="#">EN</a></span>
      <span class="top-social" aria-label="โซเชียลมีเดีย">
        <a href="https://www.facebook.com/share/1Ez81X9Yjh/" target="_blank" rel="noopener" aria-label="Facebook"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M13.5 21v-8h2.5l.4-3h-2.9V8.2c0-.9.3-1.5 1.5-1.5H16.5V4.1S15.4 4 14.3 4c-2.3 0-3.8 1.4-3.8 3.9V10H8v3h2.5v8h3Z"/></svg></a>
        <a href="https://x.com/disabilitiesth" target="_blank" rel="noopener" aria-label="X (Twitter)"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18.24 2.25h3.31l-7.23 8.26L23 21.75h-6.66l-5.22-6.82-5.97 6.82H1.84l7.73-8.84L1.25 2.25h6.83l4.71 6.23 5.45-6.23Zm-1.16 17.52h1.83L7.01 4.13H5.04l12.04 15.64Z"/></svg></a>
        <a href="https://youtube.com/@disabilitiesthailand945" target="_blank" rel="noopener" aria-label="YouTube"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M23 7.5s-.22-1.55-.9-2.23c-.86-.9-1.82-.9-2.26-.96C16.7 4.05 12 4.05 12 4.05s-4.7 0-7.84.26c-.44.06-1.4.06-2.26.96C1.22 5.95 1 7.5 1 7.5S.77 9.31.77 11.13v1.7C.77 14.65 1 16.46 1 16.46s.22 1.55.9 2.23c.86.9 1.99.87 2.49.97 1.8.17 7.61.22 7.61.22s4.7-.01 7.84-.27c.44-.06 1.4-.06 2.26-.96.68-.68.9-2.23.9-2.23s.23-1.81.23-3.63v-1.7c0-1.82-.23-3.63-.23-3.63ZM9.75 14.6V8.74l6.02 2.94-6.02 2.92Z"/></svg></a>
        <a href="https://www.tiktok.com/@disabilitiesth" target="_blank" rel="noopener" aria-label="TikTok"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M16.5 2h-3v13.5a2.5 2.5 0 1 1-2.5-2.5c.27 0 .53.04.78.12V9.9a5.6 5.6 0 0 0-.78-.06A5.55 5.55 0 1 0 16.5 15V8.4a6.86 6.86 0 0 0 4 1.28V6.6a3.86 3.86 0 0 1-4-3.83V2Z"/></svg></a>
      </span>
    </div>
  </div>
</div>

<!-- ===== Accessibility bar (behaviour preserved) ===== -->
<div class="a11y-bar" role="region" aria-label="ปรับการแสดงผลเพื่อการเข้าถึง">
  <div class="wrap">
    <div class="a11y-group">
      <span>ขนาดตัวอักษร</span>
      <button class="a11y-btn" data-fs=".9" aria-label="อักษรขนาดเล็ก">ก</button>
      <button class="a11y-btn active" data-fs="1" aria-label="อักษรขนาดปกติ" style="font-size:1rem">ก</button>
      <button class="a11y-btn" data-fs="1.18" aria-label="อักษรขนาดใหญ่" style="font-size:1.2rem">ก</button>
    </div>
    <div class="a11y-group">
      <span>การแสดงผล</span>
      <button class="a11y-btn active" data-theme="" aria-label="แสดงผลปกติ">C</button>
      <button class="a11y-btn sw-white" data-theme="hc-white" aria-label="อักษรขาวพื้นดำ">C</button>
      <button class="a11y-btn sw-yellow" data-theme="hc-yellow" aria-label="อักษรเหลืองพื้นดำ">C</button>
    </div>
  </div>
</div>

<!-- ===== Header ===== -->
<header class="site" id="top">
  <div class="nav">
    <a href="#top" class="brand" aria-label="หน้าแรก สมาคมสภาคนพิการทุกประเภทแห่งประเทศไทย">
      <span class="logo"><img src="<?php echo DTH_URI; ?>/Pic/dth-logo.png" alt="โลโก้ Disabilities Thailand" onerror="this.style.display='none'"></span>
      <span class="name"><b>สภาคนพิการทุกประเภทแห่งประเทศไทย</b><span>Disabilities Thailand</span></span>
    </a>
    <nav class="nav-pill" id="menu" aria-label="เมนูหลัก">
      <a href="#top" class="active">หน้าแรก</a>
      <div class="has-sub">
        <a href="<?php echo esc_url( home_url('/about/') ); ?>" aria-haspopup="true" aria-expanded="false">เกี่ยวกับเรา <span class="caret" aria-hidden="true">▾</span></a>
        <div class="sub">
          <a href="<?php echo esc_url( home_url('/about/') ); ?>#history">ความเป็นมา</a>
          <a href="<?php echo esc_url( home_url('/about/') ); ?>#board">คณะกรรมการ</a>
          <a href="<?php echo esc_url( home_url('/staff/') ); ?>">เจ้าหน้าที่สมาคม</a>
          <a href="<?php echo esc_url( home_url('/about/') ); ?>#milestones">ผลงานสภา</a>
          <a href="<?php echo esc_url( home_url('/regulations/') ); ?>">ข้อบังคับ/ระเบียบ</a>
          <a href="#contact">ติดต่อเรา</a>
        </div>
      </div>
      <div class="has-sub">
        <a href="#network" aria-haspopup="true" aria-expanded="false">เครือข่าย <span class="caret" aria-hidden="true">▾</span></a>
        <div class="sub">
          <a href="<?php echo esc_url( home_url('/about/') ); ?>#members">องค์การคนพิการ</a>
          <a href="<?php echo esc_url( home_url('/provinces/') ); ?>">สภาฯ ประจำจังหวัด</a>
          <a href="#network">หน่วยงานที่เกี่ยวข้อง</a>
        </div>
      </div>
      <div class="has-sub">
        <a href="<?php echo esc_url( home_url('/news/') ); ?>" aria-haspopup="true" aria-expanded="false">ข่าวสารและกิจกรรม <span class="caret" aria-hidden="true">▾</span></a>
        <div class="sub">
          <a href="<?php echo esc_url( home_url('/news/') ); ?>?cat=pr">ข่าวประชาสัมพันธ์</a>
          <a href="<?php echo esc_url( home_url('/news/') ); ?>?cat=activity">กิจกรรม</a>
          <a href="<?php echo esc_url( home_url('/news/') ); ?>?cat=report">รายงานประจำปี</a>
        </div>
      </div>
      <div class="has-sub">
        <a href="#rights" aria-haspopup="true" aria-expanded="false">ข้อมูลสำคัญ <span class="caret" aria-hidden="true">▾</span></a>
        <div class="sub">
          <a href="<?php echo esc_url( home_url('/proposals/') ); ?>">ข้อเสนอ</a>
          <a href="<?php echo esc_url( home_url('/media/') ); ?>?cat=law">กฎหมาย</a>
          <a href="<?php echo esc_url( home_url('/media/') ); ?>?cat=magazine">DTH-Magazine</a>
          <a href="#rights">สิทธิคนพิการที่ควรรู้</a>
          <a href="#qa">คำถามที่พบบ่อย</a>
          <a href="<?php echo esc_url( home_url('/media/') ); ?>">คลังสื่อ / อินโฟกราฟิก</a>
        </div>
      </div>
    </nav>
    <div class="nav-actions">
      <div class="search-mini" role="search">
        <input type="text" placeholder="ค้นหา…" aria-label="ค้นหา">
        <button aria-label="ค้นหา">⌕</button>
      </div>
    </div>
    <button class="burger" id="burger" aria-label="เปิดเมนู" aria-expanded="false"><span></span><span></span><span></span></button>
  </div>
</header>

<!-- ===== Hero slider (real DTH banners) ===== -->
<section class="hero" aria-label="ภาพสไลด์">
  <div class="slides" id="slides" aria-live="polite">
    <div class="slide welcome-slide on" style="background-image:url('<?php echo DTH_URI; ?>/Pic/hero-welcome.png')">
      <div class="cap"><span class="tag">ยินดีต้อนรับ</span><h2>สมาคมสภาคนพิการทุกประเภทแห่งประเทศไทย</h2><p>ส่งเสริมสิทธิ พัฒนาคุณภาพชีวิต และสร้างสังคมที่เท่าเทียมสำหรับทุกคน</p></div>
    </div>
  </div>
  <button class="hero-arrow prev" id="prev" aria-label="สไลด์ก่อนหน้า">‹</button>
  <button class="hero-arrow next" id="next" aria-label="สไลด์ถัดไป">›</button>
  <div class="hero-dots" id="dots" role="tablist" aria-label="เลือกสไลด์"></div>
</section>

<main id="main">

<!-- ===== Follow DTH (Facebook Page Plugin) ===== -->
<section class="block wash-mint" id="follow">
  <div class="wrap">
    <div class="kicker"><span class="ic" aria-hidden="true">📣</span><h2>ติดตาม DTH</h2><a href="https://www.facebook.com/disabilitiesth" target="_blank" rel="noopener" class="more see-all">ไปที่เพจ Facebook <span class="arr" aria-hidden="true">→</span></a></div>
    <div class="fb-embed">
      <iframe title="Facebook Page สมาคมสภาคนพิการทุกประเภทแห่งประเทศไทย"
        src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fdisabilitiesth&tabs=timeline&width=500&height=750&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true"
        width="500" height="750" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowfullscreen="true" loading="lazy"
        allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>
    </div>
  </div>
</section>

<!-- ===== Rights tabs ===== -->
<section class="block" id="rights">
  <div class="wrap">
    <div class="rights-shell" data-rights-tabs>
      <div class="rights-head">
        <h2>สิทธิคนพิการที่ควรรู้</h2>
        <p>เลือกดูข้อมูลสำคัญตามหมวดที่ต้องการ เพื่อเข้าถึงสิทธิพื้นฐานและช่องทางช่วยเหลือได้รวดเร็วขึ้น</p>
      </div>
      <div class="rights-tabs" role="tablist" aria-label="หมวดสิทธิคนพิการ">
        <button class="rights-tab active" role="tab" aria-selected="true" data-target="r-id">บัตรคนพิการ</button>
        <button class="rights-tab" role="tab" aria-selected="false" data-target="r-allow">เบี้ยความพิการ</button>
        <button class="rights-tab" role="tab" aria-selected="false" data-target="r-edu">การศึกษาและการทำงาน</button>
        <button class="rights-tab" role="tab" aria-selected="false" data-target="r-help">ร้องเรียนและช่วยเหลือ</button>
      </div>
      <article class="rights-panel active" id="r-id" role="tabpanel">
        <div class="rights-copy">
          <span class="right-kicker">เอกสารสำคัญ</span>
          <h3>บัตรคนพิการ</h3>
          <p>จุดเริ่มต้นของการเข้าถึงสิทธิพื้นฐานหลายด้าน ทั้งสวัสดิการ การรักษาพยาบาล การศึกษา และสิ่งอำนวยความสะดวก</p>
          <ul class="rights-list"><li>เอกสารที่ต้องใช้ในการยื่นคำขอ</li><li>ขั้นตอนการออกบัตรและต่ออายุ</li><li>หน่วยงานและจุดบริการที่เกี่ยวข้อง</li></ul>
          <a href="https://dth.or.th/knowledge/45-%e0%b8%aa%e0%b8%96%e0%b8%b2%e0%b8%99%e0%b8%9e%e0%b8%a2%e0%b8%b2%e0%b8%9a%e0%b8%b2%e0%b8%a5%e0%b9%80%e0%b8%ad%e0%b8%81%e0%b8%8a%e0%b8%99/" target="_blank" rel="noopener" class="pill-btn rights-cta">ดูสถานพยาบาลที่ออกเอกสารรับรอง</a>
        </div>
        <div class="rights-media-card"><span class="badge">ข้อมูลอ้างอิง</span><h4>สรุปขั้นตอนทำบัตร</h4><div class="row"><span>ผู้มีสิทธิ</span><strong>คนพิการทุกประเภท</strong></div><div class="row"><span>สถานที่ยื่น</span><strong>พมจ. / รพ.รัฐ</strong></div><div class="row"><span>อายุบัตร</span><strong>8 ปี</strong></div></div>
      </article>
      <article class="rights-panel" id="r-allow" role="tabpanel">
        <div class="rights-copy">
          <span class="right-kicker">สวัสดิการ</span>
          <h3>เบี้ยความพิการ</h3>
          <p>สรุปข้อมูลที่ควรรู้ก่อนลงทะเบียนรับสิทธิ รวมถึงเงื่อนไข เอกสาร และการติดตามสถานะการรับเงิน</p>
          <ul class="rights-list"><li>คุณสมบัติและเงื่อนไขผู้มีสิทธิ</li><li>การยื่นคำขอและช่องทางติดตามผล</li><li>ข้อควรตรวจสอบเมื่อเงินยังไม่เข้า</li></ul>
          <a href="https://dth.or.th/infographic" target="_blank" rel="noopener" class="pill-btn rights-cta">ดูอินโฟกราฟิกสิทธิคนพิการ</a>
        </div>
        <div class="rights-media-card"><span class="badge">ข้อมูลอ้างอิง</span><h4>เบี้ยความพิการ</h4><div class="row"><span>ช่องทางยื่น</span><strong>อบต. / เทศบาล</strong></div><div class="row"><span>การจ่าย</span><strong>รายเดือน</strong></div><div class="row"><span>เอกสาร</span><strong>บัตรคนพิการ, ทะเบียนบ้าน</strong></div></div>
      </article>
      <article class="rights-panel" id="r-edu" role="tabpanel">
        <div class="rights-copy">
          <span class="right-kicker">โอกาสและอาชีพ</span>
          <h3>การศึกษาและการทำงาน</h3>
          <p>รวมสิทธิด้านทุนการศึกษา การฝึกอาชีพ และสิทธิในการจ้างงานที่ช่วยเพิ่มโอกาสและความมั่นคงในระยะยาว</p>
          <ul class="rights-list"><li>ทุนและสิทธิทางการศึกษาที่เกี่ยวข้อง</li><li>โครงการฝึกอาชีพและพัฒนาทักษะ</li><li>สิทธิการจ้างงานตามมาตรา 33/35</li></ul>
          <a href="https://www.jobfinfin.com/" target="_blank" rel="noopener" class="pill-btn rights-cta">ค้นหางานคนพิการ (Job Fin Fin)</a>
        </div>
        <div class="rights-media-card"><span class="badge">ข้อมูลอ้างอิง</span><h4>การจ้างงาน</h4><div class="row"><span>มาตรา 33</span><strong>จ้างงานโดยตรง</strong></div><div class="row"><span>มาตรา 35</span><strong>สัมปทาน/ฝึกงาน</strong></div><div class="row"><span>หน่วยงาน</span><strong>กรมการจัดหางาน</strong></div></div>
      </article>
      <article class="rights-panel" id="r-help" role="tabpanel">
        <div class="rights-copy">
          <span class="right-kicker">ขอความช่วยเหลือ</span>
          <h3>ร้องเรียนและประสานช่วยเหลือ</h3>
          <p>เมื่อเกิดปัญหาในการเข้าถึงสิทธิ การบริการ หรือสวัสดิการ ควรมีช่องทางที่ชัดเจนสำหรับแจ้งเรื่องและติดตามผล</p>
          <ul class="rights-list"><li>ช่องทางร้องเรียนเมื่อไม่ได้รับสิทธิ</li><li>การประสานหน่วยงานที่เกี่ยวข้อง</li><li>แนวทางเตรียมข้อมูลก่อนแจ้งเรื่อง</li></ul>
          <a href="#contact" class="pill-btn rights-cta">ดูช่องทางติดต่อ</a>
        </div>
        <div class="rights-media-card"><span class="badge">Quick Access</span><h4>ช่องทางติดต่อ</h4><div class="row"><span>สายด่วน</span><strong>1479</strong></div><div class="row"><span>โทรสมาคม</span><strong>02-354-4260</strong></div><div class="row"><span>อีเมล</span><strong>disabilitiesth@gmail.com</strong></div></div>
      </article>
    </div>
  </div>
</section>

<!-- ===== Q&A ===== -->
<section class="block wash-leaf" id="qa">
  <div class="wrap">
    <div class="qa-grid">
      <div class="qa-visual">
        <a class="qa-tile t1" href="<?php echo esc_url( home_url('/about/') ); ?>">
          <span class="qa-logo"><img src="<?php echo DTH_URI; ?>/Pic/dth-logo.png" alt="" aria-hidden="true" onerror="this.style.display='none'"></span>
          <h3>รู้จักการทำงาน<br>ของสมาคม</h3>
        </a>
        <a class="qa-tile t2" href="#network">
          <span class="qa-logos" aria-hidden="true">
            <img src="<?php echo DTH_URI; ?>/Pic/members/blind.png" alt="" onerror="this.style.display='none'">
            <img src="<?php echo DTH_URI; ?>/Pic/members/deaf.png" alt="" onerror="this.style.display='none'">
            <img src="<?php echo DTH_URI; ?>/Pic/members/physical.png" alt="" onerror="this.style.display='none'">
            <img src="<?php echo DTH_URI; ?>/Pic/members/intellectual.jpg" alt="" onerror="this.style.display='none'">
            <img src="<?php echo DTH_URI; ?>/Pic/members/autism.jpg" alt="" onerror="this.style.display='none'">
            <img src="<?php echo DTH_URI; ?>/Pic/members/mental.jpg" alt="" onerror="this.style.display='none'">
          </span>
          <h3>องค์การสมาชิก<br>และเครือข่าย</h3>
        </a>
      </div>
      <div>
        <div class="kicker"><span class="ic" aria-hidden="true">❓</span><h2>คำถามที่พบบ่อย</h2></div>
        <div class="qa-list">
          <a class="qa-item" href="https://dth.or.th/knowledge/45-%e0%b8%aa%e0%b8%96%e0%b8%b2%e0%b8%99%e0%b8%9e%e0%b8%a2%e0%b8%b2%e0%b8%9a%e0%b8%b2%e0%b8%a5%e0%b9%80%e0%b8%ad%e0%b8%81%e0%b8%8a%e0%b8%99/" target="_blank" rel="noopener"><span>ขอเอกสารรับรองความพิการได้ที่สถานพยาบาลใดบ้าง?</span><span class="arr" aria-hidden="true">→</span></a>
          <a class="qa-item" href="#rights"><span>ลงทะเบียนรับเบี้ยความพิการได้ที่ไหน?</span><span class="arr" aria-hidden="true">→</span></a>
          <a class="qa-item" href="#rights"><span>สิทธิการจ้างงานตามมาตรา 33 และ 35 ต่างกันอย่างไร?</span><span class="arr" aria-hidden="true">→</span></a>
          <a class="qa-item" href="#contact"><span>หากไม่ได้รับสิทธิที่ควรได้ จะร้องเรียนได้ทางใด?</span><span class="arr" aria-hidden="true">→</span></a>
        </div>
        <div style="margin-top:20px;display:flex;justify-content:flex-end"><a href="https://dth.or.th/knowledge" target="_blank" rel="noopener" class="see-all">ดูทั้งหมด <span class="arr" aria-hidden="true">→</span></a></div>
      </div>
    </div>
  </div>
</section>

<!-- ===== Network logos (real member organizations) ===== -->
<section class="block" id="network">
  <div class="wrap">
    <div class="kicker"><span class="ic" aria-hidden="true">🏛️</span><h2>องค์การสมาชิก 6 องค์การ</h2><a href="<?php echo esc_url( home_url('/about/') ); ?>#members" class="more see-all">ข้อมูลติดต่อทุกสมาคม <span class="arr" aria-hidden="true">→</span></a></div>
    <div class="partners">
      <a class="partner" href="https://www.facebook.com/TabodThai?locale=th_TH" target="_blank" rel="noopener"><img src="<?php echo DTH_URI; ?>/Pic/members/blind.png" alt="โลโก้สมาคมคนตาบอดแห่งประเทศไทย" loading="lazy" onerror="this.style.display='none'"><span>สมาคมคนตาบอดแห่งประเทศไทย</span></a>
      <a class="partner" href="https://www.facebook.com/pikarnpanya.bangkok?locale=th_TH" target="_blank" rel="noopener"><img src="<?php echo DTH_URI; ?>/Pic/members/intellectual.jpg" alt="โลโก้สมาคมผู้ปกครองคนพิการทางสติปัญญาแห่งประเทศไทย" loading="lazy" onerror="this.style.display='none'"><span>สมาคมผู้ปกครองคนพิการทางสติปัญญาแห่งประเทศไทย</span></a>
      <a class="partner" href="https://www.facebook.com/APTAutismThailand?locale=th_TH" target="_blank" rel="noopener"><img src="<?php echo DTH_URI; ?>/Pic/members/autism.jpg" alt="โลโก้สมาคมผู้ปกครองบุคคลออทิซึม (ไทย)" loading="lazy" onerror="this.style.display='none'"><span>สมาคมผู้ปกครองบุคคลออทิซึม (ไทย)</span></a>
      <a class="partner" href="https://www.facebook.com/nadthailand?locale=th_TH" target="_blank" rel="noopener"><img src="<?php echo DTH_URI; ?>/Pic/members/deaf.png" alt="โลโก้สมาคมคนหูหนวกแห่งประเทศไทย" loading="lazy" onerror="this.style.display='none'"><span>สมาคมคนหูหนวกแห่งประเทศไทย</span></a>
      <a class="partner" href="https://www.facebook.com/disabledofthailand?locale=th_TH" target="_blank" rel="noopener"><img src="<?php echo DTH_URI; ?>/Pic/members/physical.png" alt="โลโก้สมาคมคนพิการแห่งประเทศไทย" loading="lazy" onerror="this.style.display='none'"><span>สมาคมคนพิการแห่งประเทศไทย</span></a>
      <a class="partner" href="https://www.facebook.com/amidmh.th?locale=th_TH" target="_blank" rel="noopener"><img src="<?php echo DTH_URI; ?>/Pic/members/mental.jpg" alt="โลโก้สมาคมเพื่อผู้บกพร่องทางจิตแห่งประเทศไทย" loading="lazy" onerror="this.style.display='none'"><span>สมาคมเพื่อผู้บกพร่องทางจิตแห่งประเทศไทย</span></a>
    </div>
  </div>
</section>

<!-- ===== Government / related orgs (real) ===== -->
<section class="block wash-mint">
  <div class="wrap">
    <div class="kicker"><span class="ic" aria-hidden="true">🏛️</span><h2>หน่วยงานที่เกี่ยวข้อง</h2></div>
    <div class="partners gov-partners">
      <a class="partner gov-partner" href="https://www.m-society.go.th/home.php" target="_blank" rel="noopener"><img src="<?php echo DTH_URI; ?>/Pic/logos/logo-01.png" alt="กระทรวงการพัฒนาสังคมและความมั่นคงของมนุษย์" loading="lazy" onerror="this.style.display='none'"><span>กระทรวงการพัฒนาสังคมและความมั่นคงของมนุษย์</span></a>
      <a class="partner gov-partner" href="https://dep.go.th/th/" target="_blank" rel="noopener"><img src="<?php echo DTH_URI; ?>/Pic/logos/logo-04.png" alt="กรมส่งเสริมและพัฒนาคุณภาพชีวิตคนพิการ" loading="lazy" onerror="this.style.display='none'"><span>กรมส่งเสริมและพัฒนาคุณภาพชีวิตคนพิการ</span></a>
      <a class="partner gov-partner" href="https://www.nhso.go.th" target="_blank" rel="noopener"><img src="<?php echo DTH_URI; ?>/Pic/logos/logo-05.png" alt="สำนักงานหลักประกันสุขภาพแห่งชาติ" loading="lazy" onerror="this.style.display='none'"><span>สำนักงานหลักประกันสุขภาพแห่งชาติ (สปสช.)</span></a>
      <a class="partner gov-partner" href="https://www.thaihealth.or.th" target="_blank" rel="noopener"><img src="<?php echo DTH_URI; ?>/Pic/logos/logo-06.png" alt="สำนักงานกองทุนสนับสนุนการสร้างเสริมสุขภาพ" loading="lazy" onerror="this.style.display='none'"><span>สำนักงานกองทุนสนับสนุนการสร้างเสริมสุขภาพ (สสส.)</span></a>
      <a class="partner gov-partner" href="https://www.doe.go.th/prd/main" target="_blank" rel="noopener"><img src="<?php echo DTH_URI; ?>/Pic/logos/logo-12.png" alt="กรมการจัดหางาน" loading="lazy" onerror="this.style.display='none'"><span>กรมการจัดหางาน</span></a>
      <a class="partner gov-partner" href="https://www.moe.go.th" target="_blank" rel="noopener"><img src="<?php echo DTH_URI; ?>/Pic/logos/logo-13.png" alt="กระทรวงศึกษาธิการ" loading="lazy" onerror="this.style.display='none'"><span>กระทรวงศึกษาธิการ</span></a>
      <a class="partner gov-partner" href="https://www.ohchr.org/en/treaty-bodies/crpd" target="_blank" rel="noopener"><img src="<?php echo DTH_URI; ?>/Pic/logos/crpd.png" alt="คณะกรรมการว่าด้วยสิทธิคนพิการแห่งสหประชาชาติ" loading="lazy" onerror="this.style.display='none'"><span>คณะกรรมการว่าด้วยสิทธิคนพิการแห่งสหประชาชาติ</span></a>
      <a class="partner gov-partner" href="https://www.internationaldisabilityalliance.org/" target="_blank" rel="noopener"><img src="<?php echo DTH_URI; ?>/Pic/logos/IDA-Logo.png" alt="International Disability Alliance" loading="lazy" onerror="this.style.display='none'"><span>International Disability Alliance</span></a>
    </div>
  </div>
</section>

<!-- ===== Hotline ===== -->
<section class="block">
  <div class="wrap">
    <div class="hotline">
      <div class="l"><h3>สายด่วนคนพิการ</h3><p>กรมส่งเสริมและพัฒนาคุณภาพชีวิตคนพิการ</p></div>
      <a href="tel:1479" class="call" aria-label="โทรสายด่วนคนพิการ 1479"><svg class="im im-lg" viewBox="0 0 24 24" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.8 19.8 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.08 4.18 2 2 0 0 1 4.06 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92Z"/></svg> 1479</a>
    </div>
  </div>
</section>

<!-- ===== Contact ===== -->
<section class="block wash-leaf" id="contact">
  <div class="wrap">
    <div class="kicker"><span class="ic" aria-hidden="true">📍</span><h2>ติดต่อสมาคม</h2></div>
    <div class="cal-grid">
      <div class="card" style="padding:clamp(24px,3vw,34px)">
        <h3 style="color:var(--brand-dark);font-size:1.3rem;margin-bottom:14px">สมาคมสภาคนพิการทุกประเภทแห่งประเทศไทย</h3>
        <p style="color:var(--muted);margin-bottom:14px">255 ห้อง 6-8 ชั้น 3 อาคารศูนย์พัฒนาและฝึกอบรมคนพิการแห่งเอเชียและแปซิฟิก (APCD) ถนนราชวิถี แขวงทุ่งพญาไท เขตราชเทวี กรุงเทพมหานคร 10400</p>
        <p style="color:var(--muted);margin-bottom:8px"><svg class="im im-lg" viewBox="0 0 24 24" aria-hidden="true"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/></svg> disabilitiesth@gmail.com</p>
        <a href="tel:023544260" class="pill-btn"><svg class="im im-lg" viewBox="0 0 24 24" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.8 19.8 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.08 4.18 2 2 0 0 1 4.06 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92Z"/></svg> 02-354-4260</a>
      </div>
      <div class="card" style="overflow:hidden;min-height:320px;padding:0"><iframe title="แผนที่ตั้งสมาคม" loading="lazy" style="width:100%;height:100%;min-height:320px;border:0;display:block" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3875.15139515162!2d100.52614701483063!3d13.769742190335837!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30e29952a2cdf38b%3A0x184a992ec58439a3!2z4Liq4Lih4Liy4LiE4Lih4Liq4Lig4Liy4LiE4LiZ4Lie4Li04LiB4Liy4Lij4LiX4Li44LiB4Lib4Lij4Liw4LmA4Lig4LiX4LmB4Lir4LmI4LiH4Lib4Lij4Liw4LmA4LiX4Lio4LmE4LiX4Lii!5e0!3m2!1sen!2sth!4v1649090216442!5m2!1sen!2sth"></iframe></div>
    </div>
  </div>
</section>

</main>

<!-- ===== Footer ===== -->
<footer class="site">
  <div class="wrap">
    <div class="foot">
      <div class="flogo"><img src="<?php echo DTH_URI; ?>/Pic/dth-logo-wide.png" alt="โลโก้ DTH" onerror="this.style.display='none'"></div>
      <div>
        <h4>สมาคมสภาคนพิการทุกประเภทแห่งประเทศไทย</h4>
        <address>
          255 ห้อง 6-8 ชั้น 3 อาคาร APCD ถนนราชวิถี<br>
          แขวงทุ่งพญาไท เขตราชเทวี กรุงเทพมหานคร 10400<br>
          โทรศัพท์ <a href="tel:023544260">02-354-4260</a><br>
          อีเมล <a href="mailto:disabilitiesth@gmail.com">disabilitiesth@gmail.com</a>
        </address>
      </div>
    </div>
    <div class="foot-policy">
      <a href="#top">หน้าแรก</a>
      <a href="<?php echo esc_url( home_url('/about/') ); ?>">เกี่ยวกับเรา</a>
      <a href="<?php echo esc_url( home_url('/about/') ); ?>#board">คณะกรรมการ</a>
      <a href="<?php echo esc_url( home_url('/about/') ); ?>#milestones">ผลงานสภา</a>
      <a href="<?php echo esc_url( home_url('/about/') ); ?>#members">องค์การคนพิการ</a>
      <a href="#network">หน่วยงานที่เกี่ยวข้อง</a>
      <a href="<?php echo esc_url( home_url('/news/') ); ?>">ข่าวสารและกิจกรรม</a>
      <a href="#rights">สิทธิคนพิการที่ควรรู้</a>
      <a href="<?php echo esc_url( home_url('/media/') ); ?>?cat=law">กฎหมาย</a>
          <a href="<?php echo esc_url( home_url('/media/') ); ?>?cat=magazine">DTH-Magazine</a>
      <a href="<?php echo esc_url( home_url('/regulations/') ); ?>">เอกสารดาวน์โหลด</a>
      <a href="<?php echo esc_url( home_url('/media/') ); ?>">คลังสื่อ / อินโฟกราฟิก</a>
      <a href="#contact">ติดต่อเรา</a>
      <a href="<?php echo esc_url( home_url('/sitemap/') ); ?>">ผังเว็บไซต์</a>
      <a href="<?php echo esc_url( home_url('/development/') ); ?>">ขั้นตอนการพัฒนา</a>
      <a href="https://dth.or.th/" target="_blank" rel="noopener">เว็บไซต์ทางการ dth.or.th</a>
    </div>
    <div class="foot-copy">© 2569 สงวนลิขสิทธิ์โดยสมาคมสภาคนพิการทุกประเภทแห่งประเทศไทย (Disabilities Thailand)</div>
  </div>
</footer>

<!-- ===== Floating contact ===== -->
<div class="fab-wrap" id="fab">
  <div class="fab-panel" id="fabPanel" role="menu" aria-label="ช่องทางติดต่อ">
    <button class="fab-item" type="button" id="openMsg" role="menuitem"><span class="ico ico-msg" aria-hidden="true"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M3 11 21 3l-8 18-2.5-7.5L3 11Z"/></svg></span> ส่งข้อความถึงทีมงาน</button>
    <a class="fab-item" href="https://www.facebook.com/share/1Ez81X9Yjh/" target="_blank" rel="noopener" role="menuitem"><span class="ico ico-fb" aria-hidden="true"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M13.5 21v-8h2.5l.4-3h-2.9V8.2c0-.9.3-1.5 1.5-1.5H16.5V4.1S15.4 4 14.3 4c-2.3 0-3.8 1.4-3.8 3.9V10H8v3h2.5v8h3Z"/></svg></span> Facebook</a>
    <a class="fab-item" href="tel:023544260" role="menuitem"><span class="ico ico-tel" aria-hidden="true"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M6.6 10.8a15.1 15.1 0 0 0 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1A17 17 0 0 1 3 4c0-.6.4-1 1-1h3.6c.6 0 1 .4 1 1 0 1.2.2 2.4.6 3.6.1.4 0 .8-.3 1l-2.3 2.2Z"/></svg></span> โทร 02-354-4260</a>
    <a class="fab-item" href="mailto:disabilitiesth@gmail.com" role="menuitem"><span class="ico ico-mail" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="m4 7 8 6 8-6"/></svg></span> อีเมล</a>
  </div>
  <button class="fab-main" id="fabMain" aria-label="เปิดช่องทางติดต่อ" aria-expanded="false" aria-controls="fabPanel">
    <img class="ic-open" src="<?php echo DTH_URI; ?>/Pic/dth-logo.png" alt="" aria-hidden="true">
    <svg class="ic-close" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>
  </button>
</div>

<!-- ===== Message modal ===== -->
<div class="modal-back" id="msgBack">
  <div class="modal" role="dialog" aria-modal="true" aria-labelledby="msgTitle">
    <div class="modal-head"><h3 id="msgTitle">ส่งข้อความถึงทีมงาน</h3><button class="modal-x" id="closeMsg" aria-label="ปิด">✕</button></div>
    <div id="msgForm">
      <div class="field"><label for="mName">ชื่อของคุณ</label><input id="mName" type="text" placeholder="ชื่อ-นามสกุล"></div>
      <div class="field"><label for="mContact">ช่องทางติดต่อกลับ</label><input id="mContact" type="text" placeholder="เบอร์โทร / อีเมล / LINE ID"></div>
      <div class="field"><label for="mMsg">ข้อความ</label><textarea id="mMsg" rows="4" placeholder="พิมพ์ข้อความที่ต้องการสอบถาม…"></textarea></div>
      <button class="pill-btn" id="sendMsg" type="button" style="width:100%;justify-content:center">ส่งข้อความ →</button>
    </div>
    <div id="msgDone" style="display:none;text-align:center;padding:14px 0">
      <div class="ok-ic" aria-hidden="true"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="m8 12.5 2.8 2.8L16 9.5"/></svg></div><h3 style="color:var(--brand-dark);margin:8px 0">ส่งข้อความเรียบร้อย</h3><p style="color:var(--muted)">ทีมงานจะติดต่อกลับโดยเร็วที่สุด ขอบคุณครับ/ค่ะ</p>
    </div>
  </div>
</div>

<script>
  // ---- Accessibility: font size ----
  document.querySelectorAll('[data-fs]').forEach(b=>b.addEventListener('click',()=>{
    document.documentElement.style.setProperty('--fs',b.dataset.fs);
    document.querySelectorAll('[data-fs]').forEach(x=>x.classList.remove('active'));b.classList.add('active');
  }));
  // ---- Accessibility: contrast ----
  document.querySelectorAll('[data-theme]').forEach(b=>b.addEventListener('click',()=>{
    document.body.classList.remove('hc-white','hc-yellow');
    if(b.dataset.theme)document.body.classList.add(b.dataset.theme);
    document.querySelectorAll('[data-theme]').forEach(x=>x.classList.remove('active'));b.classList.add('active');
  }));
  // ---- Header shadow ----
  const hdr=document.querySelector('header.site');
  addEventListener('scroll',()=>hdr.classList.toggle('scrolled',scrollY>10));
  // ---- Mobile menu ----
  const burger=document.getElementById('burger'),menu=document.getElementById('menu');
  burger.addEventListener('click',()=>{const o=menu.classList.toggle('open');burger.setAttribute('aria-expanded',o);});
  document.querySelectorAll('.has-sub > a').forEach(a=>a.addEventListener('click',e=>{
    if(matchMedia('(max-width:760px)').matches){e.preventDefault();const li=a.parentElement,o=li.classList.toggle('open');a.setAttribute('aria-expanded',o);}
  }));
  // ---- Hero slider ----
  const slides=[...document.querySelectorAll('.slide')],dots=document.getElementById('dots');
  let i=0,timer;
  slides.forEach((s,idx)=>{const d=document.createElement('button');d.setAttribute('role','tab');d.setAttribute('aria-label','สไลด์ '+(idx+1));if(idx===0)d.classList.add('on');d.addEventListener('click',()=>go(idx));dots.appendChild(d);});
  function go(n){slides[i].classList.remove('on');dots.children[i].classList.remove('on');i=(n+slides.length)%slides.length;slides[i].classList.add('on');dots.children[i].classList.add('on');}
  const reduce=matchMedia('(prefers-reduced-motion:reduce)').matches;
  function start(){if(!reduce)timer=setInterval(()=>go(i+1),5500);}
  function stop(){clearInterval(timer);}
  document.getElementById('next').addEventListener('click',()=>{go(i+1);stop();start();});
  document.getElementById('prev').addEventListener('click',()=>{go(i-1);stop();start();});
  const heroEl=document.querySelector('.hero');heroEl.addEventListener('mouseenter',stop);heroEl.addEventListener('mouseleave',start);
  start();
  // ---- Tab panels (news + media share [data-tabwrap]) ----
  document.querySelectorAll('[data-tabwrap]').forEach(wrap=>{
    const tabs=wrap.querySelectorAll('.tabbar .tab');
    tabs.forEach(t=>t.addEventListener('click',()=>{
      tabs.forEach(x=>{x.classList.remove('active');x.setAttribute('aria-selected','false');});
      t.classList.add('active');t.setAttribute('aria-selected','true');
      wrap.querySelectorAll('.tabpanel').forEach(p=>p.classList.remove('active'));
      const panel=wrap.querySelector('#'+t.dataset.target);if(panel)panel.classList.add('active');
    }));
  });
  // ---- Rights tabs ----
  document.querySelectorAll('[data-rights-tabs]').forEach(wrap=>{
    const tabs=[...wrap.querySelectorAll('.rights-tab')];
    tabs.forEach(tab=>tab.addEventListener('click',()=>{
      tabs.forEach(t=>{t.classList.remove('active');t.setAttribute('aria-selected','false');});
      wrap.querySelectorAll('.rights-panel').forEach(p=>p.classList.remove('active'));
      tab.classList.add('active');tab.setAttribute('aria-selected','true');
      const panel=wrap.querySelector('#'+tab.dataset.target);if(panel)panel.classList.add('active');
    }));
  });
  // ---- Floating contact ----
  const fab=document.getElementById('fab'),fabMain=document.getElementById('fabMain');
  fabMain.addEventListener('click',()=>{const o=fab.classList.toggle('open');fabMain.setAttribute('aria-expanded',o);});
  document.addEventListener('click',e=>{if(fab.classList.contains('open')&&!fab.contains(e.target)){fab.classList.remove('open');fabMain.setAttribute('aria-expanded','false');}});
  // ---- Message modal ----
  const back=document.getElementById('msgBack'),mForm=document.getElementById('msgForm'),mDone=document.getElementById('msgDone');
  function openModal(){back.classList.add('show');mForm.style.display='';mDone.style.display='none';setTimeout(()=>document.getElementById('mName').focus(),60);}
  function closeModal(){back.classList.remove('show');}
  document.getElementById('openMsg').addEventListener('click',()=>{fab.classList.remove('open');fabMain.setAttribute('aria-expanded','false');openModal();});
  document.getElementById('closeMsg').addEventListener('click',closeModal);
  back.addEventListener('click',e=>{if(e.target===back)closeModal();});
  addEventListener('keydown',e=>{if(e.key==='Escape')closeModal();});
  document.getElementById('sendMsg').addEventListener('click',()=>{const n=document.getElementById('mName').value.trim(),m=document.getElementById('mMsg').value.trim();if(!n||!m){alert('กรุณากรอกชื่อและข้อความ');return;}mForm.style.display='none';mDone.style.display='block';});
</script>
<!-- back to top -->
<button class="to-top" id="toTop" type="button">
  <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 19V5"/><path d="m5 12 7-7 7 7"/></svg>
  กลับไปด้านบนเว็บไซต์
</button>
<script>
(()=>{const b=document.getElementById('toTop');if(!b)return;
const onS=()=>{const on=scrollY+innerHeight>=document.documentElement.scrollHeight-320&&scrollY>200;b.classList.toggle('show',on);document.body.classList.toggle('totop-on',on);};
addEventListener('scroll',onS,{passive:true});onS();
b.addEventListener('click',()=>scrollTo({top:0,behavior:'smooth'}));})();
</script>
<!-- scroll reveal -->
<script>
(()=>{ // animate content into view; respects reduced-motion
if(matchMedia('(prefers-reduced-motion: reduce)').matches)return;
const sel='.kicker,.news-head,.card,.partner,.qa-item,.qa-tile,.member-card,.board-card,.obj-list li,.ms-cat,.ms p,.vision-quote,.about-stat,.hotline,.rights-shell,.prose p,.obj-intro,.tabbar,.fb-embed,.table-wrap,.board-poster,.hub-card,.hub-side-item,.timeline li,.page-hero .logo-badge,.page-hero .lead,.foot';
const els=[...document.querySelectorAll(sel)].filter(el=>!el.closest('.rv'));
const groups=new Map();
els.forEach(el=>{el.classList.add('rv');
  const p=el.parentElement,i=groups.get(p)||0;
  el.style.setProperty('--rvd',Math.min(i*70,420)+'ms');groups.set(p,i+1)});
let pending=els.slice(),throttled=false;
const reveal=el=>{el.classList.add('in');
  setTimeout(()=>{el.classList.remove('rv','in');el.style.removeProperty('--rvd')},950+parseInt(el.style.getPropertyValue('--rvd')||0))};
const check=()=>{const vh=innerHeight;
  pending=pending.filter(el=>{const r=el.getBoundingClientRect();
    if(r.top<vh*.94){reveal(el);return false}return true});
  if(!pending.length){removeEventListener('scroll',onScroll);removeEventListener('resize',onScroll)}};
const onScroll=()=>{if(throttled)return;throttled=true;setTimeout(()=>{throttled=false;check()},90)};
addEventListener('scroll',onScroll,{passive:true});
addEventListener('resize',onScroll,{passive:true});
check();
})();
</script>
<?php
get_footer();
